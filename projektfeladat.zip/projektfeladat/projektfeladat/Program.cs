﻿using System;
using System.Collections.Generic;
using System.IO;

namespace program
{
    class ProgramAdat
    {
        public string Nev { get; set; }
        public string Kategoria { get; set; }
        public int Ev { get; set; }

        public ProgramAdat(string sor)
        {
            var adatok = sor.Split(';');
            Nev = adatok[0];
            Kategoria = adatok[1];
            Ev = int.Parse(adatok[2]);
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            string fajl = "program.txt";
            List<ProgramAdat> lista = new List<ProgramAdat>();

            foreach (var sor in File.ReadAllLines(fajl))
            {
                lista.Add(new ProgramAdat(sor));
            }

            Console.WriteLine("Beolvasott adatok:");
            Console.WriteLine("-------------------");

            foreach (var p in lista)
            {
                Console.WriteLine($"Név: {p.Nev}, Kategória: {p.Kategoria}, Év: {p.Ev}");
            }

            Console.WriteLine("\nÖsszes program száma: " + lista.Count);

            var legrgebbi = lista[0];
            foreach (var p in lista)
            {
                if (p.Ev < legrgebbi.Ev)
                    legrgebbi = p;
            }

            Console.WriteLine($"\nLegrégebbi program: {legrgebbi.Nev} ({legrgebbi.Ev})");

            Console.WriteLine("\nProgram vége.");
            Console.ReadKey();
        }
    }
}
